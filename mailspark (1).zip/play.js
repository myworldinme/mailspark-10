const id = 4;

const cookie = "uid".id;

console.log(cookie);